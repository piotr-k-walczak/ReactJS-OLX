import React from "react";

function Loading(props) {
  return <h1 style={{ color: "white" }}>Ładowanie...</h1>;
}

export default Loading;
