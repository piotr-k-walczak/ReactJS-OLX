export default {
  path: "http://localhost:3001",
};
